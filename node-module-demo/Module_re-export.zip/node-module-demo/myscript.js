const ariOpr = require("./firstModule")
const opr = require("./secondModule")



console.log("The result is: " + ariOpr(5, 10))
//  console.log("The result is: "+ariOpr.add(5,10))
//  console.log(ariOpr.sub(5,10))
// console.log(a.secretKey)
console.log(opr(20, 5))
// console.log(opr.mul(20,5))
// //console.log(opr(20,5))node 