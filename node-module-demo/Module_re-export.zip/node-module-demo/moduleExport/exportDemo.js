const fs =require("fs");
import fs from "fs";

console.log(
    fs.readFileSync("./exportDemo.js", "utf8")
)