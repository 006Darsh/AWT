// import fs from "fs";

// console.log(
//     fs.readFileSync("es6.mjs", "utf8")
// )

// import square from "./math.mjs";
import{s as square,c as cube} from "./math.mjs";


console.log(square(2));
console.log(cube(2));