const mul=function(a,b){
    return(a*b)
}

module.exports=mul
//module.exports={mul}