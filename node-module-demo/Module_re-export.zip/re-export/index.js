import multiply, { Division } from "./main.js";

console.log(multiply(2, 3));
console.log(Division(6, 4));