const Division = function(x, y){
    let ans = x / y;
    return ans;
}

export default Division;