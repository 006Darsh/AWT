import multiply from './first.js';
import Division from './second.js';

export default multiply;
export {Division};